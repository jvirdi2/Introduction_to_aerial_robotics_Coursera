function [F, M] = controller(t, state, des_state, params)
%CONTROLLER  Controller for the quadrotor
%
%   state: The current state of the robot with the following fields:
%   state.pos = [x; y; z], state.vel = [x_dot; y_dot; z_dot],
%   state.rot = [phi; theta; psi], state.omega = [p; q; r]
%
%   des_state: The desired states are:
%   des_state.pos = [x; y; z], des_state.vel = [x_dot; y_dot; z_dot],
%   des_state.acc = [x_ddot; y_ddot; z_ddot], des_state.yaw,
%   des_state.yawdot
%
%   params: robot parameters

%   Using these current and desired states, you have to compute the desired
%   controls


% =================== Your code goes here ===================
% Gains
Kpphi=200;
Kvphi=1;
Kptheta=200;
Kvtheta=1;
Kpsi=200;
Kvsi=1;
kp1=300;
kd1=2;
kp2=300;
kd2=2;
kp3=800;
kd3=1;

gravity=params.gravity();
mass=params.mass();
yaw_des=des_state.yaw;
yawdot_des=des_state.yawdot;
pos_des_1=des_state.pos(1);
pos_des_2=des_state.pos(2);
pos_des_3=des_state.pos(3);
vel_des_1=des_state.vel(1);
vel_des_2=des_state.vel(2);
vel_des_3=des_state.vel(3);

pos_state_1=state.pos(1);
pos_state_2=state.pos(2);
pos_state_3=state.pos(3);

vel_state_1=state.vel(1);
vel_state_2=state.vel(2);
vel_state_3=state.vel(3);

acc_des_1=des_state.acc(1)+kp1*(-pos_state_1+pos_des_1)+kd1*(-vel_state_1+vel_des_1);
acc_des_2=des_state.acc(2)+kp2*(-pos_state_2+pos_des_2)+kd2*(-vel_state_2+vel_des_2);
acc_des_3=des_state.acc(3);


minF=params.minF();
maxF=params.maxF();



rot_state_1=state.rot(1);
rot_state_2=state.rot(2);
rot_state_3=state.rot(3);
p=state.omega(1);
q=state.omega(2);
r=state.omega(3);
yaw_des_sin=sin(yaw_des);
yaw_des_cos=cos(yaw_des);

phi_des=(1/gravity)*(acc_des_1*yaw_des_sin-acc_des_2*yaw_des_cos);
theta_des=(1/gravity)*(acc_des_1*yaw_des_cos+acc_des_2*yaw_des_sin);

u2=[Kpphi*(phi_des-rot_state_1)+Kvphi*(-p);  
    Kptheta*(theta_des-rot_state_2)+Kvtheta*(-q); 
    Kpsi*(yaw_des-rot_state_3)+Kvsi*(yawdot_des-r)];

u1=mass*(gravity+acc_des_3+kp3*(-pos_state_3+pos_des_3)+kd3*(-vel_state_3+vel_des_3));
% Thrust
F = min(max(u1,minF),maxF);

% Moment
M = u2;

% =================== Your code ends here ===================

end

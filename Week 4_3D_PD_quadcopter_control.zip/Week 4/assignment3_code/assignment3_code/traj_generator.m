function [ desired_state ] = traj_generator(t, state, waypoints)
% TRAJ_GENERATOR: Generate the trajectory passing through all
% positions listed in the waypoints list
%
% NOTE: This function would be called with variable number of input arguments.
% During initialization, it will be called with arguments            
% trajectory_generator([], [], waypoints) and later, while testing, it will be
% called with only t and state as arguments, so your code should be able to
% handle that. This can be done by checking the number of arguments to the
% function using the "nargin" variable, check the MATLAB documentation for more
% information.
%
% t,state: time and current state (same variable as "state" in controller)
% that you may use for computing desired_state
%
% waypoints: The 3xP matrix listing all the points you much visited in order
% along the generated trajectory
%
% desired_state: Contains all the information that is passed to the
% controller for generating inputs for the quadrotor
%
% It is suggested to use "persistent" variables to store the waypoints during
% the initialization call of trajectory_generator.


%% Example code:
% Note that this is an example of naive trajectory generator that simply moves
% the quadrotor along a stright line between each pair of consecutive waypoints
% using a constant velocity of 0.5 m/s. Note that this is only a sample, and you
% should write your own trajectory generator for the submission.
%
%persistent waypoints0 traj_time d0

%


%% Fill in your code here

% desired_state.pos = zeros(3,1);
% desired_state.vel = zeros(3,1);
% desired_state.acc = zeros(3,1);
% desired_state.yaw = 0;

persistent waypoints0 constants derivative_coeffs_matrix  segment_length 
%syms x
%time_matrix(x)=[sym(1),x,x^2,x^3,x^4,x^5,x^6,x^7];
%vel_matrix(x)=diff(time_matrix);
%acc_matrix(x)=diff(vel_matrix);
if nargin > 2
    waypoints0 = transpose(waypoints);
    length_waypoints=length(waypoints0);
    segment_length=length_waypoints-1;
    LHS_matrix=zeros(8*(length_waypoints-1));
    RHS_matrix=zeros(8*(length_waypoints-1),3);
    for_derivative=0:(8-1);
    derivative_coeffs_matrix=zeros(6,8);
    derivative_coeffs_matrix(1,:)=for_derivative;
    for j=2:6 % derivative coeffs matrix
        for_derivative_update=[zeros(1,j-1),for_derivative(1:(8-(j-1)))];
        derivative_coeffs_matrix(j,:)=derivative_coeffs_matrix(j-1,:).*for_derivative_update;
    end
    for i=1:segment_length   % Initial 8 equations which are related to point information
            RHS_matrix(2*i-1,:)=waypoints0(i,:);
            RHS_matrix(2*i,:)=waypoints0(i+1,:);
            LHS_matrix(2*i-1,8*i-7)=1;
            LHS_matrix(2*i,(8*i-7):8*i)=ones(1,8);
    end
    for point=2:(length_waypoints-1)    %for derivatives
        for k=1:6
            LHS_matrix(8+6*(point-2)+k,(8*(point-2)+1):(8*(point-2)+8))=derivative_coeffs_matrix(k,:);
            LHS_matrix(8+6*(point-2)+k,(8*(point-1)+k+1))=(-1)*derivative_coeffs_matrix(k,k+1);
        end
    end
    % velocity,acc and jerk are 0 at first point and last point
    for m=1:3
        LHS_matrix(8+6*(length_waypoints-2)+m,m+1)=derivative_coeffs_matrix(m,m+1); 
    end
    for m=4:6
        LHS_matrix(8+6*(length_waypoints-2)+m,(8*(length_waypoints-2)+1):(8*(length_waypoints-2)+8))=derivative_coeffs_matrix(m-3,:); 
    end
    constants=LHS_matrix\RHS_matrix;
else
    time_interval=3.5;% equal since drone has to traverse equal distances
    i=1;
    while i<=segment_length
        if t>=time_interval*(i-1) && t<time_interval*(i)
            T_parameter=(t-time_interval*(i-1))/time_interval;
            time_matrix=[1,T_parameter,T_parameter^2,T_parameter^3,T_parameter^4,T_parameter^5,T_parameter^6,T_parameter^7]';
            vel_matrix=[0,1,2*T_parameter,3*T_parameter^2,4*T_parameter^3,5*T_parameter^4,6*T_parameter^5,7*T_parameter^6]'/time_interval;
            acc_matrix=[0,0,2,6*T_parameter,12*T_parameter^2,20*T_parameter^3,30*T_parameter^4,42*T_parameter^5]'/(time_interval^2);
            constants_reqd=constants(8*i-7:8*i,:);
            for_pos_eval=constants_reqd.*time_matrix;
            desired_state.pos=transpose(sum(for_pos_eval));
            for_vel_eval=constants_reqd.*vel_matrix;
            desired_state.vel=transpose(sum(for_vel_eval));
            for_acc_eval=constants_reqd.*acc_matrix;
            desired_state.acc=transpose(sum(for_acc_eval));
            desired_state.yaw = 0;
            desired_state.yawdot =0;
            break
        else
            i=i+1;
            if t>=time_interval*(segment_length)
                desired_state.pos=transpose(waypoints0(segment_length+1,:));
                desired_state.vel=zeros(3,1);
                desired_state.acc=zeros(3,1);
                desired_state.yaw = 0;
                desired_state.yawdot =0;   
                break
            end
        end
    end
end

            
        
        
    
    
    
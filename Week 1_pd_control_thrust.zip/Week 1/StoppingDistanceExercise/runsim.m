clear all
close all
stopping_gui
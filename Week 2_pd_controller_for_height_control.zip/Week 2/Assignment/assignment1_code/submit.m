close all;
clear;

% This is your controller
controlhandle = @controller;

evaluate(controlhandle);

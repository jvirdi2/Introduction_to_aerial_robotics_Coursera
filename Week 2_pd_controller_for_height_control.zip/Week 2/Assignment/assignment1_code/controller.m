function [ u ] = pd_controller(~, s, s_des, params)
%PD_CONTROLLER  PD controller for the height
%
%   s: 2x1 vector containing the current state [z; v_z]
%   s_des: 2x1 vector containing desired state [z; v_z]
%   params: robot parameters
u_min=params.u_min;
u_max=params.u_max;
error_P=s_des(1)-s(1);
error_I=s_des(2)-s(2);
Kp=(50);
Kv=(10);
mass=params.mass;
u_1 = mass*(Kp*error_P+Kv*error_I+9.81);
u_actual=min(max(u_min,u_1),u_max);
u=u_actual;

% FILL IN YOUR CODE HERE 


end

